<?php
require_once "Conexion.php";

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");

// ==============================
// VALIDAR PARÁMETRO
// ==============================
if (!isset($_GET["id_grupo"])) {
    echo json_encode([
        "error" => true,
        "msg"   => "Falta id_grupo"
    ]);
    exit;
}

$idGrupo = intval($_GET["id_grupo"]);

// ==============================
// FUNCIÓN PARA CONVERTIR ENTERO → HH:mm
// ==============================
function convertirHora($valor) {
    $h = floor($valor / 100);   // horas
    $m = $valor % 100;         // minutos
    return sprintf("%02d:%02d", $h, $m);
}

try {

    $pdo = Conexion::conectar();

    // ==============================
    // CONSULTAR HORARIOS DEL GRUPO
    // ==============================
    $sql = $pdo->prepare("
        SELECT dia, inicio, fin 
        FROM horario 
        WHERE id_grupo = ?
        ORDER BY dia ASC, inicio ASC
    ");
    $sql->execute([$idGrupo]);

    $horarios = [];

    while ($row = $sql->fetch(PDO::FETCH_ASSOC)) {

        $horarios[] = [
            "dia"    => intval($row["dia"]),
            "inicio" => convertirHora(intval($row["inicio"])),
            "fin"    => convertirHora(intval($row["fin"]))
        ];
    }

    echo json_encode([
        "error"    => false,
        "horarios" => $horarios
    ]);

} catch (Exception $e) {

    echo json_encode([
        "error" => true,
        "msg"   => "Error en servidor",
        "detalle" => $e->getMessage()
    ]);
}
