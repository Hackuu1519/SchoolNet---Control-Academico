<?php
header("Content-Type: application/json; charset=UTF-8");

require_once "qr_generar_todos.php";

// ===============================
// VALIDAR PARAMETRO
// ===============================
if (!isset($_GET["id_grupo"])) {
    echo json_encode([
        "error" => true,
        "msg"   => "Falta id_grupo"
    ]);
    exit;
}

$idGrupo = $_GET["id_grupo"];

// ===============================
// GENERAR TODOS LOS QR
// ===============================
$resultado = qr_generar_todos($idGrupo);

// ===============================
// RESPUESTA FINAL
// ===============================
echo json_encode($resultado);
