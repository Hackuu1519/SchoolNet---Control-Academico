<?php
// ===============================================
// CONFIGURACIÓN GENERAL DEL SISTEMA
// ===============================================

// URL BASE PARA FOTOS DE ALUMNOS
define("URL_BASE_ALUMNOS", "http://192.168.1.236/wsescuela2/Alumnos/archivos/");

// URL BASE PARA EL MÓDULO DOCENTES (PDF, grupos, reportes)
define("URL_BASE_DOCENTES", "http://192.168.1.236/wsescuela2/Docentes/");
