<?php
require_once "Conexion.php";
require_once "phpqrcode/qrlib.php";

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

if (!isset($_GET["api"])) {
    echo json_encode(["error" => true, "msg" => "API no definida"]);
    exit;
}


// ============================================================
// 1️⃣ GENERAR QR DE UN ALUMNO
// Formato QR:   id_grupo | id_alumno | A/P/F/J | token
// ============================================================
if ($_GET["api"] == "generar") {

    if (!isset($_POST["id_grupo"]) || !isset($_POST["id_alumno"])) {
        echo json_encode(["error" => true, "msg" => "Faltan datos"]);
        exit;
    }

    $idGrupo  = $_POST["id_grupo"];
    $idAlumno = $_POST["id_alumno"];

    $pdo = Conexion::conectar();

    // Validar alumno inscrito y aceptado
    $sql = $pdo->prepare("
        SELECT id_inscripcion
        FROM inscripcion
        WHERE id_grupo = ? AND id_estudiante = ? AND estado = 2
        LIMIT 1
    ");
    $sql->execute([$idGrupo, $idAlumno]);

    if ($sql->rowCount() == 0) {
        echo json_encode(["error" => true, "msg" => "El alumno no está aceptado en este grupo"]);
        exit;
    }

    // Crear carpeta QR si no existe
       $folder = __DIR__ . "/qr/";
    if (!file_exists($folder)) {
        mkdir($folder, 0777, true);
    }

    // Token único para seguridad
    $token = substr(hash('sha256', $idGrupo . $idAlumno . microtime()), 0, 12);

    // Contenido dentro del QR
    // LETRA DEFAULT = A (Asistencia)
    $contenido = "$idGrupo|$idAlumno|A|$token";

    // Nombre del archivo QR
    $fileName = "QR_" . $idGrupo . "_" . $idAlumno . ".png";
    $filePath = $folder . $fileName;

    // Generar QR
    QRcode::png($contenido, $filePath, QR_ECLEVEL_H, 10, 4);

    // URL pública del QR
    $publicURL = "http://192.168.1.236/wsescuela2/Docentes/qr/" . $fileName;

    echo json_encode([
        "error" => false,
        "msg"   => "QR generado correctamente",
        "qr"    => $publicURL,
        "contenido" => $contenido
    ]);
    exit;
}

?>
