<?php
require_once "Conexion.php";
require_once "ADAsistencia.php";

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET");
header("Access-Control-Allow-Headers: Content-Type");

if (!isset($_GET["api"])) {
    echo json_encode(["error" => true, "msg" => "API no definida"]);
    exit;
}

$asis = new ADAsistencia();
$api  = $_GET["api"];

function distanciaGPS($lat1, $lon1, $lat2, $lon2) {
    $radio = 6371000;
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);

    $a = sin($dLat/2)**2 +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
         sin($dLon/2)**2;

    $c = 2 * atan2(sqrt($a), sqrt(1-$a));
    return $radio * $c;
}

try {

    /* ============================================================
       1️⃣ REGISTRO MANUAL
    ============================================================ */
    if ($api == "registrar") {
        if (!isset($_POST["id_grupo"], $_POST["id_estudiante"], $_POST["estado"])) {
            throw new Exception("Faltan datos");
        }

        echo json_encode($asis->registrarManual(
            $_POST["id_grupo"],
            $_POST["id_estudiante"],
            $_POST["estado"]
        ));
        exit;
    }

    if ($api == "editar") {

    if (!isset($_POST["id_pase"], $_POST["estado"])) {
        echo json_encode(["error"=>true, "msg"=>"Faltan parámetros"]);
        exit;
    }

    echo json_encode(
        $asis->editarPase($_POST["id_pase"], $_POST["estado"])
    );
    exit;
}


/* ============================================================
   📄 GENERAR PDF DEL GRUPO
============================================================ */
if ($api == "reporte_pdf") {

    if (!isset($_POST["id_grupo"], $_POST["inicio"], $_POST["fin"])) {
        echo json_encode(["error" => true, "msg" => "Faltan parámetros"]);
        exit;
    }

    $idGrupo = $_POST["id_grupo"];
    $inicio  = $_POST["inicio"];
    $fin     = $_POST["fin"];

    // Ruta donde se guardará el PDF
    $nombrePDF = "reporte_" . $idGrupo . "_" . time() . ".pdf";
    $rutaPDF   = __DIR__ . "/reportes/" . $nombrePDF;

    // Crear carpeta si no existe
    if (!file_exists(__DIR__ . "/reportes")) {
        mkdir(__DIR__ . "/reportes", 0777, true);
    }

    // 📌 Generar el PDF desde ADAsistencia
    require_once "fpdf/fpdf.php";  // Asegúrate de tener FPDF en tu servidor

    $resultado = $asis->generarPDF($idGrupo, $inicio, $fin, $rutaPDF);

    if ($resultado["error"]) {
    echo json_encode([
        "error" => true,
        "msg"   => $resultado["msg"]  // ← MUY IMPORTANTE
    ]);
    exit;
}

    echo json_encode([
        "error" => false,
     "url" => URL_BASE_DOCENTES . "reportes/" . $nombrePDF
    ]);
    exit;
}


    /* ============================================================
       2️⃣ REGISTRO QR
    ============================================================ */
    if ($api == "registrar_qr") {
        if (!isset($_POST["codigo_qr"], $_POST["id_grupo"])) {
            throw new Exception("Faltan datos");
        }

        echo json_encode($asis->registrarQR(
            $_POST["codigo_qr"],
            $_POST["id_grupo"]
        ));
        exit;
    }

    /* ============================================================
       ⭐ REGISTRO GPS MASIVO
    ============================================================ */
    if ($api == "registrar_gps_masivo") {

        if (!isset($_POST["id_grupo"], $_POST["presentes"], $_POST["faltantes"])) {
            echo json_encode(["error" => true, "msg" => "Faltan parámetros"]);
            exit;
        }

        $idGrupo   = $_POST["id_grupo"];
        $presentes = json_decode($_POST["presentes"]);
        $faltantes = json_decode($_POST["faltantes"]);

        echo json_encode(
            $asis->registrarGPSMasivo($idGrupo, $presentes, $faltantes)
        );
        exit;
    }
            /* ============================================================
            ⭐ ESTADÍSTICAS DEL GRUPO (Pie + Barras + Riesgo)
            ============================================================ */
        if ($api == "estadisticas") {
    if (!isset($_POST["id_grupo"])) {
        echo json_encode(["error" => true, "msg" => "Falta id_grupo"]);
        exit;
    }

    echo json_encode(
        $asis->estadisticasGrupo($_POST["id_grupo"])
    );
    exit;
}


            /* ============================================================
            3️⃣ INFO DEL ALUMNO
            ============================================================ */
            if ($api == "info") {

                if (!isset($_POST["id_estudiante"], $_POST["id_grupo"])) {
                    throw new Exception("Faltan parámetros");
                }

                echo json_encode(
                    $asis->infoAlumno($_POST["id_estudiante"], $_POST["id_grupo"])
                );
                exit;
            }

    /* ============================================================
       4️⃣ RESUMEN
    ============================================================ */
    if ($api == "resumen") {

        if (!isset($_POST["id_estudiante"], $_POST["id_grupo"])) {
            throw new Exception("Faltan parámetros");
        }

        echo json_encode(
            $asis->resumen($_POST["id_estudiante"], $_POST["id_grupo"])
        );
        exit;
    }

    /* ============================================================
       5️⃣ HISTORIAL
    ============================================================ */
    if ($api == "historial") {

        if (!isset($_POST["id_estudiante"], $_POST["id_grupo"])) {
            throw new Exception("Faltan parámetros");
        }

        echo json_encode(
            $asis->historial($_POST["id_estudiante"], $_POST["id_grupo"])
        );
        exit;
    }

    /* ============================================================
       7️⃣ LISTA PARA REGISTRO MANUAL (CORREGIDO)
    ============================================================ */
    if ($api == "lista") {

        if (!isset($_POST["id_grupo"])) {
            echo json_encode(["error"=>true, "msg"=>"Falta id_grupo"]);
            exit;
        }

        echo json_encode(
            $asis->listaManual($_POST["id_grupo"])
        );

        exit;
    }

    /* ============================================================
       6️⃣ HORARIO
    ============================================================ */
    if ($api == "horario") {

        if (!isset($_POST["id_grupo"])) {
            throw new Exception("Faltan parámetros");
        }

        echo json_encode(
            $asis->horario($_POST["id_grupo"])
        );
        exit;
    }

    /* ============================================================
       ❌ API NO VÁLIDA
    ============================================================ */
    throw new Exception("API no válida");

} catch (Exception $e) {

    echo json_encode([
        "error" => true,
        "msg"   => $e->getMessage()
    ]);

    exit;
}
