<?php
header("Content-Type: application/json; charset=UTF-8");

require_once "Conexion.php";
require_once "phpqrcode/qrlib.php";

// =================================================================
// VALIDAR PARÁMETROS
// =================================================================
if (!isset($_POST["id_grupo"]) || !isset($_POST["id_alumno"])) {
    echo json_encode(["error" => true, "msg" => "Faltan datos"]);
    exit;
}

$idGrupo  = $_POST["id_grupo"];
$idAlumno = $_POST["id_alumno"];

try {

    $pdo = Conexion::conectar();

    // =================================================================
    // 1️⃣ VALIDAR QUE EL GRUPO EXISTA
    // =================================================================
    $sqlG = $pdo->prepare("SELECT id_grupo FROM grupo WHERE id_grupo = ?");
    $sqlG->execute([$idGrupo]);

    if ($sqlG->rowCount() == 0) {
        echo json_encode(["error" => true, "msg" => "El grupo no existe"]);
        exit;
    }

    // =================================================================
    // 2️⃣ VALIDAR QUE EL ALUMNO ESTÉ ACEPTADO EN EL GRUPO
    // =================================================================
    $sqlA = $pdo->prepare("
        SELECT 
            e.id_estudiante,
            CONCAT(e.app, ' ', e.apm, ' ', e.nombre) AS nombre
        FROM inscripcion i
        INNER JOIN estudiante e ON e.id_estudiante = i.id_estudiante
        WHERE i.id_grupo = ? AND i.id_estudiante = ? AND i.estado = 2
        LIMIT 1
    ");
    $sqlA->execute([$idGrupo, $idAlumno]);
    $al = $sqlA->fetch(PDO::FETCH_ASSOC);

    if (!$al) {
        echo json_encode(["error" => true, "msg" => "El alumno no está aceptado en el grupo"]);
        exit;
    }

    // =================================================================
    // 3️⃣ CARPETA
    // =================================================================
    $folder = __DIR__ . "/qr/";
    if (!file_exists($folder)) {
        mkdir($folder, 0777, true);
    }

    // =================================================================
    // 4️⃣ GENERAR QR
    // =================================================================
    $token = substr(hash("sha256", $idGrupo . $idAlumno . microtime()), 0, 12);
    $contenido = "$idGrupo|$idAlumno|A|$token";

    $fileName = "QR_" . $idGrupo . "_" . $idAlumno . ".png";
    $filePath = $folder . $fileName;

    QRcode::png($contenido, $filePath, QR_ECLEVEL_H, 10, 4);

    // PATH RELATIVO ✔✔✔
    $rutaQR = "qr/" . $fileName;

    // =================================================================
    // 6️⃣ RESPUESTA
    // =================================================================
    echo json_encode([
        "error"     => false,
        "msg"       => "QR generado correctamente",
        "grupo"     => $idGrupo,
        "alumno"    => [
            "id"      => $idAlumno,
            "nombre"  => $al["nombre"]
        ],
        "qr"        => $rutaQR,
        "contenido" => $contenido
    ]);

} catch (Exception $e) {

    echo json_encode([
        "error" => true,
        "msg" => "Error: " . $e->getMessage()
    ]);
}
