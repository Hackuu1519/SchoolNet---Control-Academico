<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

require_once "Conexion.php";

if (!isset($_POST["id_docente"])) {
    echo json_encode(["error" => true, "msg" => "Falta id_docente"]);
    exit;
}

$id = $_POST["id_docente"];
$con = Conexion::conectar();

/* ============================================================
   1️⃣ CLASES IMPARTIDAS
   ============================================================ */
$sql = $con->prepare("
    SELECT COUNT(*) AS total
    FROM grupo
    WHERE id_docente = :id
");
$sql->bindParam(":id", $id);
$sql->execute();
$clases_impartidas = $sql->fetch(PDO::FETCH_ASSOC)["total"];

/* ============================================================
   2️⃣ LISTAS PASADAS
   ============================================================ */
$sql = $con->prepare("
    SELECT COUNT(*) AS total
    FROM pase p
    INNER JOIN inscripcion i ON i.id_inscripcion = p.id_inscripcion
    INNER JOIN grupo g ON g.id_grupo = i.id_grupo
    WHERE g.id_docente = :id
");
$sql->bindParam(":id", $id);
$sql->execute();
$listas_pasadas = $sql->fetch(PDO::FETCH_ASSOC)["total"];

/* ============================================================
   3️⃣ ALUMNOS ACTIVOS
   ============================================================ */
$sql = $con->prepare("
    SELECT COUNT(*) AS total
    FROM inscripcion i
    INNER JOIN grupo g ON g.id_grupo = i.id_grupo
    WHERE g.id_docente = :id
    AND i.estado = 2
");
$sql->bindParam(":id", $id);
$sql->execute();
$alumnos_activos = $sql->fetch(PDO::FETCH_ASSOC)["total"];

/* ============================================================
   4️⃣ PROMEDIO GENERAL ASISTENCIA
   ============================================================ */
$sql = $con->prepare("
    SELECT
        SUM(CASE WHEN p.valor = 1 THEN 1 ELSE 0 END) AS asistencias,
        COUNT(*) AS total
    FROM pase p
    INNER JOIN inscripcion i ON i.id_inscripcion = p.id_inscripcion
    INNER JOIN grupo g ON g.id_grupo = i.id_grupo
    WHERE g.id_docente = :id
");
$sql->bindParam(":id", $id);
$sql->execute();
$row = $sql->fetch(PDO::FETCH_ASSOC);

$prom_asistencia = ($row["total"] > 0)
    ? round(($row["asistencias"] / $row["total"]) * 100)
    : 0;

/* ============================================================
   5️⃣ PIE CHART
   ============================================================ */
$sql = $con->prepare("
    SELECT
        SUM(CASE WHEN p.valor = 1 THEN 1 ELSE 0 END) AS asistencias,
        SUM(CASE WHEN p.valor = 2 THEN 1 ELSE 0 END) AS permisos,
        SUM(CASE WHEN p.valor = 3 THEN 1 ELSE 0 END) AS faltas,
        SUM(CASE WHEN p.valor = 4 THEN 1 ELSE 0 END) AS justificados
    FROM pase p
    INNER JOIN inscripcion i ON i.id_inscripcion = p.id_inscripcion
    INNER JOIN grupo g ON g.id_grupo = i.id_grupo
    WHERE g.id_docente = :id
");
$sql->bindParam(":id", $id);
$sql->execute();
$pie = $sql->fetch(PDO::FETCH_ASSOC);

/* ============================================================
   6️⃣ BAR CHART — CORREGIDO ✔
   ============================================================ */
$sql = $con->prepare("
    SELECT 
        g.Asignatura AS grupo,
        ROUND(
            (
                SUM(CASE WHEN p.valor = 1 THEN 1 ELSE 0 END) * 100.0
                /
                COUNT(*)
            )
        ) AS asistencia
    FROM pase p
    INNER JOIN inscripcion i ON i.id_inscripcion = p.id_inscripcion
    INNER JOIN grupo g ON g.id_grupo = i.id_grupo
    WHERE g.id_docente = :id
    GROUP BY g.id_grupo
");
$sql->bindParam(":id", $id);
$sql->execute();
$barras = $sql->fetchAll(PDO::FETCH_ASSOC);

/* ============================================================
   RESPUESTA FINAL JSON
   ============================================================ */

echo json_encode([
    "error" => false,

    "clases_impartidas" => $clases_impartidas,
    "listas_pasadas" => $listas_pasadas,
    "alumnos_activos" => $alumnos_activos,
    "promedio_asistencia" => $prom_asistencia,

    "pie" => [
        "asistencias" => (int)$pie["asistencias"],
        "permisos"    => (int)$pie["permisos"],
        "faltas"      => (int)$pie["faltas"],
        "justificados"=> (int)$pie["justificados"]
    ],

    "barras" => $barras

], JSON_UNESCAPED_UNICODE);

exit;
