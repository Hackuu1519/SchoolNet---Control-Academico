<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");

if (!isset($_POST["id_grupo"]) || !isset($_POST["latitud"]) || !isset($_POST["longitud"])) {
    echo json_encode(["error" => true, "msg" => "Faltan datos"]);
    exit;
}

$idGrupo = $_POST["id_grupo"];
$lat = floatval($_POST["latitud"]);
$lon = floatval($_POST["longitud"]);

$carpeta = "ubicacion_docente/";

if (!file_exists($carpeta)) {
    mkdir($carpeta, 0777, true);
}

$data = [
    "id_grupo" => $idGrupo,
    "latitud" => $lat,
    "longitud" => $lon,
    "fecha" => date("Y-m-d H:i:s")
];

file_put_contents($carpeta . $idGrupo . ".json", json_encode($data));

echo json_encode(["error" => false, "msg" => "Ubicación guardada"]);
