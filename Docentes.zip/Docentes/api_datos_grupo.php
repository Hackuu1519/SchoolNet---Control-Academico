<?php
require_once "Conexion.php";

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");

// ============================================================
// 🌐 URL BASE PARA IMÁGENES DE GRUPOS
// ============================================================
define("URL_DOC_GRUPOS", "http://192.168.1.236/wsescuela2/Docentes/archivos/");

// Validar parámetro
if (!isset($_GET["id_grupo"])) {
    echo json_encode(["error" => true, "msg" => "Falta id_grupo"]);
    exit;
}

$idGrupo = $_GET["id_grupo"];

try {
    $pdo = Conexion::conectar();

    // ============================================================
    // 1️⃣ OBTENER DATOS DEL GRUPO
    // ============================================================
    $sql = $pdo->prepare("
        SELECT 
            g.id_grupo,
            g.clave,
            g.asignatura,
            g.carrera,
            g.periodo,
            g.estado,
            CONCAT('" . URL_DOC_GRUPOS . "grupo_', g.id_grupo, '.jpg') AS imagen
        FROM grupo g
        WHERE g.id_grupo = ?
        LIMIT 1
    ");
    $sql->execute([$idGrupo]);

    if ($sql->rowCount() === 0) {
        echo json_encode(["error" => true, "msg" => "Grupo no encontrado"]);
        exit;
    }

    $grupo = $sql->fetch(PDO::FETCH_ASSOC);

    // ============================================================
    // 2️⃣ CONTAR ALUMNOS ACEPTADOS
    // ============================================================
    $sqlAl = $pdo->prepare("
        SELECT COUNT(*) 
        FROM inscripcion
        WHERE id_grupo = ? AND estado = 2
    ");
    $sqlAl->execute([$idGrupo]);
    $grupo["alumnos"] = (int)$sqlAl->fetchColumn();

    // ============================================================
    // 3️⃣ OBTENER HORARIOS DEL GRUPO
    // ============================================================
    $sqlH = $pdo->prepare("
        SELECT dia, inicio, fin, aula
        FROM horario
        WHERE id_grupo = ?
        ORDER BY dia ASC
    ");
    $sqlH->execute([$idGrupo]);
    $grupo["horarios"] = $sqlH->fetchAll(PDO::FETCH_ASSOC);

    // ============================================================
    // 4️⃣ RESPUESTA FINAL
    // ============================================================
    echo json_encode([
        "error" => false,
        "msg"   => "OK",
        "grupo" => $grupo
    ]);

} catch (Exception $e) {
    echo json_encode(["error" => true, "msg" => $e->getMessage()]);
}
