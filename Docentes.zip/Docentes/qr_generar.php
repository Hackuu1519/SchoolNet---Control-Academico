<?php
require_once "phpqrcode/qrlib.php";

function generarQR($idGrupo, $idAlumno) {

    // === Carpeta ===
       $folder = __DIR__ . "/qr/";
    if (!file_exists($folder)) {
        mkdir($folder, 0777, true);
    }

    // === Nombre de archivo ===
    $fileName = "QR_" . $idGrupo . "_" . $idAlumno . ".png";
    $filePath = $folder . $fileName;

    // === Token anti-fraude ===
    $token = substr(hash("sha256", $idGrupo . $idAlumno . microtime()), 0, 12);

    // === Contenido del QR ===
    // Formato oficial del sistema
    $contenido = "$idGrupo|$idAlumno|A|$token";

    // === Generar QR ===
    QRcode::png(
        $contenido,
        $filePath,
        QR_ECLEVEL_H,  // alta corrección
        10,            // tamaño
        4              // margen
    );

    // === URL pública para Android ===
    $url = "http://192.168.1.236/wsescuela2/Docentes/qr/" . $fileName;

    return [
        "error"     => false,
        "msg"       => "QR generado",
        "archivo"   => $fileName,
        "url"       => $url,
        "contenido" => $contenido
    ];
}
?>
