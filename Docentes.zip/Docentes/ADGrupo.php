<?php
require_once "Conexion.php";

define("URL_BASE", "http://192.168.1.236/wsescuela2/Docentes/");

class ADGrupo {

public function listar($idDocente) {

    $pdo = Conexion::conectar();

    $sql = "
        SELECT
            g.id_grupo,
            g.clave,
            g.periodo,
            g.carrera,
            g.asignatura,
            g.estado,

            CONCAT('" . URL_BASE . "archivos/grupo_', g.id_grupo, '.jpg') AS foto,

            (SELECT COUNT(*) FROM inscripcion 
             WHERE id_grupo = g.id_grupo AND estado = 2) AS alumnos

        FROM grupo g
        WHERE g.id_docente = :id
        ORDER BY g.id_grupo DESC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(":id", $idDocente);
    $stmt->execute();

    $grupos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 🔧 AGREGAR HORARIO COMO OBJETO JSON (NO STRING)
    foreach ($grupos as &$g) {

        $sqlH = $pdo->prepare("
            SELECT dia, inicio, fin, aula
            FROM horario
            WHERE id_grupo = ?
            ORDER BY dia ASC
            LIMIT 1
        ");
        $sqlH->execute([$g["id_grupo"]]);

        $h = $sqlH->fetch(PDO::FETCH_ASSOC);

        if ($h) {

            // convertir a texto con ceros si hace falta
            $inicio = str_pad($h["inicio"], 4, "0", STR_PAD_LEFT);
            $fin    = str_pad($h["fin"], 4, "0", STR_PAD_LEFT);

            // REGRESAR OBJETO PHP (que se convertirá en JSON)
            $g["horario"] = [
                "dia"    => (int)$h["dia"],
                "inicio" => $inicio,
                "fin"    => $fin,
                "aula"   => $h["aula"]
            ];

        } else {
            $g["horario"] = null;
        }
    }

    return $grupos;
}

    /* ============================================================
       GUARDAR NUEVO GRUPO
    ============================================================ */
    public function guardar($clave, $periodo, $carrera, $asignatura, $idDocente, $estado, $horariosJSON) {

        $pdo = Conexion::conectar();

        $sql = "
            INSERT INTO grupo (clave, periodo, carrera, asignatura, id_docente, estado)
            VALUES (?, ?, ?, ?, ?, ?)
        ";

        $stmt = $pdo->prepare($sql);

        if (!$stmt->execute([$clave, $periodo, $carrera, $asignatura, $idDocente, $estado])) {
            return false;
        }

        $idGrupo = $pdo->lastInsertId();

        // Guardar horarios en tabla HORIZONTAL
        $this->guardarHorarios($idGrupo, $horariosJSON);

        return $idGrupo;
    }




    /* ============================================================
       GUARDAR TODOS LOS HORARIOS JSON
    ============================================================ */
    public function guardarHorarios($idGrupo, $horariosJSON) {

        $pdo = Conexion::conectar();

        // Borrar horarios anteriores
        $del = $pdo->prepare("DELETE FROM horario WHERE id_grupo = ?");
        $del->execute([$idGrupo]);

        // Convertir JSON
        $horarios = json_decode($horariosJSON, true);

        if (!is_array($horarios)) return false;

        foreach ($horarios as $h) {

            $sql = "
                INSERT INTO horario (dia, inicio, fin, aula, id_grupo)
                VALUES (?, ?, ?, ?, ?)
            ";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $h["dia"],
                $h["inicio"],
                $h["fin"],
                $h["aula"],
                $idGrupo
            ]);
        }

        return true;
    }




    /* ============================================================
       DETALLE COMPLETO DEL GRUPO
    ============================================================ */
    public function detalle($idGrupo) {

        $pdo = Conexion::conectar();

        $sql = "
            SELECT 
                g.id_grupo,
                g.clave,
                g.periodo,
                g.carrera,
                g.asignatura,
                g.estado,
               CONCAT('" . URL_BASE . "archivos/grupo_', g.id_grupo, '.jpg') AS imagen
            FROM grupo g
            WHERE g.id_grupo = ?
        ";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([$idGrupo]);

        $grupo = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$grupo) return null;


        // Contar estudiantes aceptados
        $sqlAl = "
            SELECT COUNT(*) AS total
            FROM inscripcion
            WHERE id_grupo = ? AND estado = 2
        ";
        $al = $pdo->prepare($sqlAl);
        $al->execute([$idGrupo]);
        $grupo["estudiantes"] = $al->fetch(PDO::FETCH_ASSOC)["total"];


        // Obtener horarios ordenados por día
        $sqlH = "
            SELECT dia, inicio, fin, aula
            FROM horario
            WHERE id_grupo = ?
            ORDER BY dia ASC
        ";
        $h = $pdo->prepare($sqlH);
        $h->execute([$idGrupo]);

        $grupo["horarios"] = $h->fetchAll(PDO::FETCH_ASSOC);

        return $grupo;
    }




    /* ============================================================
       ACTUALIZAR GRUPO
    ============================================================ */
    public function actualizar($idGrupo, $clave, $periodo, $carrera, $asignatura, $estado, $horariosJSON) {

        $pdo = Conexion::conectar();

        $sql = "
            UPDATE grupo SET
                clave = ?,
                periodo = ?,
                carrera = ?,
                asignatura = ?,
                estado = ?
            WHERE id_grupo = ?
        ";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([$clave, $periodo, $carrera, $asignatura, $estado, $idGrupo]);

        // Actualizar horarios
        $this->guardarHorarios($idGrupo, $horariosJSON);

        return true;
    }




    /* ============================================================
       ELIMINAR GRUPO + HORARIOS
    ============================================================ */
    public function eliminar($idGrupo) {

        $pdo = Conexion::conectar();

        // Borrar horarios
        $pdo->prepare("DELETE FROM horario WHERE id_grupo = ?")->execute([$idGrupo]);

        // Borrar grupo
        return $pdo->prepare("DELETE FROM grupo WHERE id_grupo = ?")->execute([$idGrupo]);
    }

}
?>
