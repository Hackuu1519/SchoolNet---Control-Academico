<?php
require_once "Conexion.php";

header("Content-Type: application/json; charset=UTF-8");

if (!isset($_GET["id_grupo"])) {
    echo json_encode([
        "error" => true,
        "msg"   => "Falta id_grupo"
    ]);
    exit;
}

$idGrupo = $_GET["id_grupo"];

try {
    $pdo = Conexion::conectar();

    $sql = $pdo->prepare("
        SELECT 
            e.id_estudiante AS id_alumno,
            CONCAT(e.app, ' ', e.apm, ' ', e.nombre) AS nombre
        FROM inscripcion i
        INNER JOIN estudiante e ON e.id_estudiante = i.id_estudiante
        WHERE i.id_grupo = :g AND i.estado = 2
        ORDER BY e.app, e.apm, e.nombre
    ");

    $sql->execute([":g" => $idGrupo]);

    echo json_encode([
        "error"   => false,
        "alumnos" => $sql->fetchAll(PDO::FETCH_ASSOC)
    ]);

} catch (Exception $e) {
    echo json_encode([
        "error" => true,
        "msg"   => "Error en servidor: " . $e->getMessage()
    ]);
}
