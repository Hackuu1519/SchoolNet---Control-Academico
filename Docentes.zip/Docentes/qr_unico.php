<?php
require_once "phpqrcode/qrlib.php";

header("Content-Type: application/json; charset=UTF-8");

try {

    // ============================
    //  VALIDAR PARÁMETROS
    // ============================
    if (!isset($_GET["grupo"]) || !isset($_GET["alumno"])) {
        throw new Exception("Faltan parámetros");
    }

    $idGrupo  = $_GET["grupo"];
    $idAlumno = $_GET["alumno"];


    // ============================
    //  CARPETA DE QR
    // ============================
    $folder = __DIR__ . "qr/";
    if (!file_exists($folder)) {
        mkdir($folder, 0777, true);
    }


    // ============================
    //  GENERAR TOKEN
    // ============================
    $token = substr(hash("sha256", $idGrupo . $idAlumno . microtime()), 0, 12);

    // Formato oficial
    $contenido = "$idGrupo|$idAlumno|A|$token";


    // ============================
    //  NOMBRE DEL ARCHIVO
    // ============================
    $fileName = "QR_" . $idGrupo . "_" . $idAlumno . ".png";
    $filePath = $folder . $fileName;


    // ============================
    //  GENERAR QR BASE
    // ============================
    QRcode::png(
        $contenido,
        $filePath,
        QR_ECLEVEL_H,
        10,
        4
    );


    // ============================
    //  ABRIR IMAGEN
    // ============================
    $img = imagecreatefrompng($filePath);
    $negro = imagecolorallocate($img, 0, 0, 0);
    $blanco = imagecolorallocate($img, 255, 255, 255);

    $w = imagesx($img);
    $h = imagesy($img);

    // Tamaño de marcadores
    $t = intval($w * 0.17);


    // ============================
    //  MARCADORES (NO BLOQUEAN DATOS)
    //  Se colocan en las esquinas externas
    // ============================

    // A - Asistencia
    imagefilledrectangle($img, 0, 0, $t, $t, $blanco);
    imagestring($img, 5, $t / 4, $t / 4, "A", $negro);

    // R - Retardo
    imagefilledrectangle($img, $w - $t, 0, $w, $t, $blanco);
    imagestring($img, 5, $w - $t + $t / 4, $t / 4, "R", $negro);

    // F - Falta
    imagefilledrectangle($img, 0, $h - $t, $t, $h, $blanco);
    imagestring($img, 5, $t / 4, $h - $t + $t / 4, "F", $negro);

    // J - Justificante
    imagefilledrectangle($img, $w - $t, $h - $t, $w, $h, $blanco);
    imagestring($img, 5, $w - $t + $t / 4, $h - $t + $t / 4, "J", $negro);

    // P - Permiso (CENTRO)
    $cx = $w / 2 - $t / 4;
    $cy = $h / 2 - $t / 4;
    imagefilledellipse($img, $w / 2, $h / 2, $t, $t, $blanco);
    imagestring($img, 5, $cx, $cy, "P", $negro);


    // ============================
    //  GUARDAR QR FINAL
    // ============================
    imagepng($img, $filePath);
    imagedestroy($img);


    // ============================
    //  URL PÚBLICA PARA ANDROID
    // ============================
    $url = "http://192.168.1.236/wsescuela2/Docentes/qr/" . $fileName;


    // ============================
    //  RESPUESTA
    // ============================
    echo json_encode([
        "error"     => false,
        "msg"       => "QR generado correctamente",
        "archivo"   => $fileName,
        "url"       => $url,
        "contenido" => $contenido
    ]);
    exit;


} catch (Exception $e) {

    echo json_encode([
        "error" => true,
        "msg" => $e->getMessage()
    ]);
    exit;
}
?>
