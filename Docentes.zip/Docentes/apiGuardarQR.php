<?php
require_once "Conexion.php";

header("Content-Type: application/json; charset=UTF-8");

if (!isset($_POST["id_alumno"]) || !isset($_POST["id_grupo"])) {
    echo json_encode(["error" => true, "msg" => "Faltan parámetros"]);
    exit;
}

$idAlumno = $_POST["id_alumno"];
$idGrupo  = $_POST["id_grupo"];

if (!isset($_FILES["qr"])) {
    echo json_encode(["error" => true, "msg" => "No se envió archivo"]);
    exit;
}

$qrTmp  = $_FILES["qr"]["tmp_name"];

// Carpeta donde guardar
$destino = "qr/alumnos/";
if (!file_exists($destino)) mkdir($destino, 0777, true);

// Nombre único ✔✔✔
$nombreQR = "qr_" . $idGrupo . "_" . $idAlumno . ".png";

// Ruta final
$rutaFinal = $destino . $nombreQR;

// Mover archivo
if (move_uploaded_file($qrTmp, $rutaFinal)) {

    echo json_encode([
        "error" => false,
        "msg" => "QR guardado correctamente",
        "archivo" => $nombreQR
    ]);

} else {
    echo json_encode(["error" => true, "msg" => "Error guardando archivo"]);
}
?>
