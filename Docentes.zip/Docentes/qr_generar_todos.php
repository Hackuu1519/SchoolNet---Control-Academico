<?php
require_once "Conexion.php";
require_once "phpqrcode/qrlib.php";

function qr_generar_todos($idGrupo) {

    try {
        $pdo = Conexion::conectar();

        // Verificar grupo existente
        $sqlGrupo = $pdo->prepare("SELECT id_grupo FROM grupo WHERE id_grupo = ?");
        $sqlGrupo->execute([$idGrupo]);

        if ($sqlGrupo->rowCount() == 0) {
            return ["error" => true, "msg" => "El grupo no existe"];
        }

        // Obtener alumnos aceptados
        $sql = $pdo->prepare("
            SELECT 
                e.id_estudiante,
                CONCAT(e.app, ' ', e.apm, ' ', e.nombre) AS nombre
            FROM inscripcion i
            INNER JOIN estudiante e ON e.id_estudiante = i.id_estudiante
            WHERE i.id_grupo = ? AND i.estado = 2
            ORDER BY e.app ASC, e.apm ASC, e.nombre ASC
        ");
        $sql->execute([$idGrupo]);
        $alumnos = $sql->fetchAll(PDO::FETCH_ASSOC);

        if (!$alumnos) {
            return ["error" => true, "msg" => "No hay alumnos aceptados en el grupo"];
        }

        // Carpeta de QR
        $folder = __DIR__ . "/qr/";
        if (!file_exists($folder)) {
            mkdir($folder, 0777, true);
        }

        $listaQR = [];

        foreach ($alumnos as $a) {

            $idAlumno = $a["id_estudiante"];

            // Token único
            $token = substr(hash("sha256", $idGrupo . $idAlumno . microtime()), 0, 12);

            // Contenido del QR
            $contenido = "$idGrupo|$idAlumno|A|$token";

            // Archivo QR
            $fileName = "QR_" . $idGrupo . "_" . $idAlumno . ".png";
            $filePath = $folder . $fileName;

            // Generar QR
            QRcode::png($contenido, $filePath, QR_ECLEVEL_H, 10, 4);

            // PATH RELATIVO (¡IMPORTANTE!)
            $urlPublica = "qr/" . $fileName;

            // Agregar al arreglo
            $listaQR[] = [
                "id_alumno" => $idAlumno,
                "nombre"    => $a["nombre"],
                "qr"        => $urlPublica,
                "contenido" => $contenido
            ];
        }

        return [
            "error" => false,
            "msg"   => "QR regenerados correctamente",
            "grupo" => $idGrupo,
            "generados" => count($listaQR),
            "alumnos" => $listaQR
        ];

    } catch (Exception $e) {
        return [
            "error" => true,
            "msg" => "Error: " . $e->getMessage()
        ];
    }
}
