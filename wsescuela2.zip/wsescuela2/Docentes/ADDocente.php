<?php
/**
 * Transacciones de la tabla DOCENTE
 * Autor original: Mario Pérez Bautista
 * Mejorado por ChatGPT
 */

require_once "Conexion.php";

class ADDocente {


    /* ==========================================================
       VALIDAR LOGIN
       0 = no existe
       1 = pass incorrecta
       2 = correcto (devuelve datos)
    ========================================================== */
public static function buscarDoc($correo, $pass) {

    $pdo = Conexion::conectar();

    $stmt = $pdo->prepare("
        SELECT 
            id_docente,
            numero,
            nombre,
            app,
            apm,
            correo,
            pass,
            genero,
            grado
        FROM docente 
        WHERE correo = :correo AND estado = 1
    ");
    $stmt->bindParam(":correo", $correo, PDO::PARAM_STR);
    $stmt->execute();

    if ($stmt->rowCount() === 0) return 0;

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verificar contraseña
    if (!password_verify($pass, $row["pass"])) {
        return 1;
    }

    // Login correcto → devolver datos COMPLETOS
    return [
        "status"      => 2,
        "id_docente"  => $row["id_docente"],
        "numero"      => $row["numero"],
        "nombre"      => $row["nombre"],
        "app"         => $row["app"],
        "apm"         => $row["apm"],
        "correo"      => $row["correo"],
        "genero"      => $row["genero"],
        "grado"       => $row["grado"]
    ];
}




    /* ==========================================================
       GUARDAR DOCENTE NUEVO
    ========================================================== */
    public static function guardar($numero, $nombre, $app, $apm, $correo, $pass, $estado, $genero, $grado) {

        $pdo = Conexion::conectar();

        // Validar correo duplicado
        $stmt = $pdo->prepare("
            SELECT correo 
            FROM docente 
            WHERE correo = :correo
        ");
        $stmt->bindParam(":correo", $correo, PDO::PARAM_STR);
        $stmt->execute();

        if ($stmt->fetchColumn() > 0) return false;

        // Guardar nuevo docente
        $stmt = $pdo->prepare("
            INSERT INTO docente 
            (numero, nombre, app, apm, correo, pass, estado, genero, grado)
            VALUES (:numero, :nombre, :app, :apm, :correo, :pass, :estado, :genero, :grado)
        ");

        $hashed = password_hash($pass, PASSWORD_ARGON2ID);

        $stmt->bindParam(":numero", $numero);
        $stmt->bindParam(":nombre", $nombre);
        $stmt->bindParam(":app", $app);
        $stmt->bindParam(":apm", $apm);
        $stmt->bindParam(":correo", $correo);
        $stmt->bindParam(":pass", $hashed);
        $stmt->bindParam(":estado", $estado);
        $stmt->bindParam(":genero", $genero);
        $stmt->bindParam(":grado", $grado);

        return $stmt->execute();
    }




    /* ==========================================================
       CONSULTAR DOCENTE POR CORREO
    ========================================================== */
    public static function consultarPorCorreo($correo) {

        try {
            $stmt = Conexion::conectar()->prepare("
                SELECT id_docente, numero, nombre, app, apm, correo, estado, genero, grado
                FROM docente 
                WHERE correo = :correo
            ");
            $stmt->bindParam(":correo", $correo);
            $stmt->execute();

            return $stmt->fetchAll(PDO::FETCH_ASSOC);

        } catch (PDOException $e) {
            return false;
        }
    }




    /* ==========================================================
       CAMBIAR CONTRASEÑA (con Argon2ID)
    ========================================================== */
    public static function cambiarPass($correo, $nuevaPass) {

        try {
            $hashed = password_hash($nuevaPass, PASSWORD_ARGON2ID);

            $stmt = Conexion::conectar()->prepare("
                UPDATE docente 
                SET pass = :pass 
                WHERE correo = :correo
            ");

            $stmt->bindParam(":pass", $hashed, PDO::PARAM_STR);
            $stmt->bindParam(":correo", $correo, PDO::PARAM_STR);

            return $stmt->execute();

        } catch (PDOException $e) {
            return false;
        }
    }




    /* ==========================================================
       ACTUALIZAR SOLO GENERO Y GRADO
    ========================================================== */
    public static function actualizarGeneroGrado($id, $genero, $grado) {

        try {
            $stmt = Conexion::conectar()->prepare("
                UPDATE docente SET 
                    genero = :genero,
                    grado = :grado
                WHERE id_docente = :id
            ");

            $stmt->bindParam(":id", $id, PDO::PARAM_INT);
            $stmt->bindParam(":genero", $genero, PDO::PARAM_INT);
            $stmt->bindParam(":grado", $grado, PDO::PARAM_INT);

            return $stmt->execute();

        } catch (PDOException $e) {
            return false;
        }
    }
}
?>
