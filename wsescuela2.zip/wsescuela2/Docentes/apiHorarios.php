<?php
require_once "Conexion.php";

header("Content-Type: application/json; charset=UTF-8");

try {

    // Validar parámetro
    if (!isset($_POST["id_grupo"])) {
        throw new Exception("Falta id_grupo");
    }

    $idGrupo = $_POST["id_grupo"];

    $pdo = Conexion::conectar();
    $sql = $pdo->prepare("
        SELECT 
            id_horario,
            dia,
            inicio,
            fin,
            aula
        FROM horario
        WHERE id_grupo = ?
        ORDER BY dia ASC, inicio ASC
    ");

    $sql->execute([$idGrupo]);
    $horarios = $sql->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "error" => false,
        "horarios" => $horarios
    ]);
    exit;

} catch (Exception $e) {

    echo json_encode([
        "error" => true,
        "msg" => $e->getMessage()
    ]);
    exit;
}
