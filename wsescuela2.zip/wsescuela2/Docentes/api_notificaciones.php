<?php
header("Content-Type: application/json");

if (!isset($_POST["id_docente"])) {
    echo json_encode(["error" => true, "msg" => "Falta id_docente"]);
    exit;
}

$id = $_POST["id_docente"];
$ruta = "notificaciones_docente/" . $id . ".json";

if (!file_exists($ruta)) {
    echo json_encode(["error" => false, "notificaciones" => []]);
    exit;
}

$data = json_decode(file_get_contents($ruta), true);

echo json_encode([
    "error" => false,
    "notificaciones" => $data
]);
