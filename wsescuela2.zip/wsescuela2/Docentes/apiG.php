<?php
require_once "ADGrupo.php";
require_once "Conexion.php";

header("Content-Type: application/json; charset=UTF-8");

if (!isset($_GET["api"])) {
    echo json_encode(["error" => true, "msg" => "API no definida"]);
    exit;
}

$api = $_GET["api"];
$db  = new ADGrupo();

try {

    // ============================================================
    // 🟦 LISTAR GRUPOS DEL DOCENTE
    // ============================================================
    if ($api == "listar") {

        if (!isset($_POST["id_docente"])) {
            throw new Exception("Falta id_docente");
        }

        $res = $db->listar($_POST["id_docente"]);

        echo json_encode([
            "error" => false,
            "grupos" => $res
        ]);
        exit;
    }



    // ============================================================
    // 🟩 GUARDAR NUEVO GRUPO
    // ============================================================
    if ($api == "guardar") {

        $required = ["clave","periodo","carrera","asignatura","id_docente","estado","horarios"];
        foreach ($required as $r) {
            if (!isset($_POST[$r])) throw new Exception("Falta parámetro: $r");
        }

        // Crear grupo
        $idGrupo = $db->guardar(
            $_POST["clave"],
            $_POST["periodo"],
            $_POST["carrera"],
            $_POST["asignatura"],
            $_POST["id_docente"],
            $_POST["estado"],
            $_POST["horarios"]
        );

        if (!$idGrupo) {
            throw new Exception("No se pudo crear el grupo");
        }

        // Guardar imagen si viene
        if (isset($_POST["imagen_base64"])) {

            if (!file_exists("archivos/")) mkdir("archivos/", 0777, true);

            $ruta = "archivos/grupo_" . $idGrupo . ".jpg";
            file_put_contents($ruta, base64_decode($_POST["imagen_base64"]));
        }

        echo json_encode([
            "error" => false,
            "id_grupo" => $idGrupo,
            "msg" => "Grupo creado correctamente"
        ]);
        exit;
    }



    // ============================================================
    // 🟦 DETALLE DEL GRUPO
    // ============================================================
    if ($api == "detalle") {

        if (!isset($_POST["id_grupo"])) {
            throw new Exception("Falta id_grupo");
        }

        $grupo = $db->detalle($_POST["id_grupo"]);

        if (!$grupo) {
            throw new Exception("Grupo no encontrado");
        }

        echo json_encode([
            "error" => false,
            "grupo" => $grupo
        ]);
        exit;
    }



    // ============================================================
    // 🟩 ACTUALIZAR GRUPO
    // ============================================================
    if ($api == "actualizar") {

        $required = ["id_grupo","clave","periodo","carrera","asignatura","estado","horarios"];
        foreach ($required as $r) {
            if (!isset($_POST[$r])) throw new Exception("Falta parámetro: $r");
        }

        $ok = $db->actualizar(
            $_POST["id_grupo"],
            $_POST["clave"],
            $_POST["periodo"],
            $_POST["carrera"],
            $_POST["asignatura"],
            $_POST["estado"],
            $_POST["horarios"]
        );

        if (!$ok) {
            throw new Exception("Error al actualizar grupo");
        }

        // Imagen
        if (isset($_POST["imagen_base64"])) {

            if (!file_exists("archivos/")) mkdir("archivos/", 0777, true);

            $ruta = "archivos/grupo_" . $_POST["id_grupo"] . ".jpg";
            file_put_contents($ruta, base64_decode($_POST["imagen_base64"]));
        }

        echo json_encode([
            "error" => false,
            "msg" => "Grupo actualizado correctamente"
        ]);
        exit;
    }



    // ============================================================
    // 🟥 ELIMINAR GRUPO
    // ============================================================
    if ($api == "eliminar") {

        if (!isset($_POST["id_grupo"])) {
            throw new Exception("Falta id_grupo");
        }

        $db->eliminar($_POST["id_grupo"]);

        // Eliminar imagen
        $ruta = "archivos/grupo_" . $_POST["id_grupo"] . ".jpg";
        if (file_exists($ruta)) unlink($ruta);

        echo json_encode([
            "error" => false,
            "msg" => "Grupo eliminado correctamente"
        ]);
        exit;
    }



    // ============================================================
    // ❌ API NO VÁLIDA
    // ============================================================
    throw new Exception("API inválida");



} catch (Exception $e) {

    echo json_encode([
        "error" => true,
        "msg" => $e->getMessage()
    ]);
    exit;
}
