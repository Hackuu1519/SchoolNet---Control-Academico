<?php
require_once "Conexion.php";

if (!isset($_GET["id_grupo"])) {
    echo json_encode(["error" => true, "msg" => "Falta id_grupo"]);
    exit;
}

$idGrupo = intval($_GET["id_grupo"]);

$pdo = Conexion::conectar();

$sql = $pdo->prepare("
    SELECT dia
    FROM horario
    WHERE id_grupo = ?
");
$sql->execute([$idGrupo]);

$dias = [];
while ($row = $sql->fetch(PDO::FETCH_ASSOC)) {
    // día numérico: 1..6
    $dias[] = intval($row["dia"]);
}

echo json_encode([
    "error" => false,
    "dias" => $dias
]);
