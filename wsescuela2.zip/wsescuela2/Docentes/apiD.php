<?php
/**
 * API para gestión de DOCENTES
 */

require_once 'ADDocente.php';
require_once 'Conexion.php';

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === "OPTIONS") {
    exit;
}


if (!isset($_GET['api'])) {
    echo json_encode(["error" => true, "msg" => "API no definida"]);
    exit;
}

$api = $_GET["api"];
$doc = new ADDocente();

try {

    // ==========================================================
    // 🟦 LOGIN
    // Respuesta esperada por Android:
    // {"error":false,"msg":0|1|2}
    // ==========================================================
if ($api == "validar") {

    if (!isset($_POST["correo"], $_POST["pass"])) {
        throw new Exception("Faltan datos");
    }

    $result = $doc->buscarDoc($_POST["correo"], $_POST["pass"]);

    // Caso 0 o 1 → solo números
    if ($result === 0 || $result === 1) {
        echo json_encode([
            "error" => false,
            "msg" => $result
        ]);
        exit;
    }

    // Caso 2 → objeto completo
    echo json_encode([
    "error" => false,
    "msg" => [
        "status"      => 2,
        "id_docente"  => $result["id_docente"],
        "numero"      => $result["numero"],
        "nombre"      => $result["nombre"],
        "app"         => $result["app"],
        "apm"         => $result["apm"],
        "correo"      => $result["correo"],
        "genero"      => $result["genero"],
        "grado"       => $result["grado"]
    ]
]);

    exit;
}



    // ==========================================================
    // 🟩 GUARDAR NUEVO DOCENTE
    // ==========================================================
// ==========================================================
// 🟩 GUARDAR NUEVO DOCENTE (CON FOTO)
// ==========================================================
if ($api == "guardar") {

    $required = ["numero","nombre","app","apm","correo","pass","estado","genero","grado"];
    foreach ($required as $r) {
        if (!isset($_POST[$r])) {
            echo json_encode(["error"=>true, "msg"=>"Falta parámetro: $r"]);
            exit;
        }
    }

    // FOTO opcional
    $foto64 = $_POST["foto"] ?? null;

    $pdo = Conexion::conectar();

    // Verificar correo duplicado
    $s = $pdo->prepare("SELECT id_docente FROM docente WHERE correo=?");
    $s->execute([$_POST["correo"]]);

    if ($s->rowCount() > 0) {
        echo json_encode(["error"=>true, "msg"=>"El correo ya está registrado"]);
        exit;
    }

    // Insertar docente
    $stmt = $pdo->prepare("
        INSERT INTO docente (numero, nombre, app, apm, correo, pass, estado, genero, grado)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $hashed = password_hash($_POST["pass"], PASSWORD_ARGON2ID);

    $ok = $stmt->execute([
        $_POST["numero"],
        $_POST["nombre"],
        $_POST["app"],
        $_POST["apm"],
        $_POST["correo"],
        $hashed,
        $_POST["estado"],
        $_POST["genero"],
        $_POST["grado"]
    ]);

    if (!$ok) {
        echo json_encode(["error"=>true, "msg"=>"No se pudo registrar"]);
        exit;
    }

    // Obtener el ID generado
    $id_docente = $pdo->lastInsertId();

    // 🔥 Guardar la foto si llegó
    if ($foto64 != null && $foto64 != "") {

        $ruta = "../Docentes/archivos/docente_$id_docente.jpg";

        $binario = base64_decode($foto64);

        file_put_contents($ruta, $binario);
    }

    echo json_encode([
        "error" => false,
        "msg"   => "Docente registrado",
        "id"    => $id_docente
    ]);
    exit;
}



    // ==========================================================
    // 🟦 CONSULTAR PERFIL POR CORREO
    // ==========================================================
    if ($api == "consultarPorCorreo") {

        if (!isset($_POST["correo"])) throw new Exception("Falta correo");

        $result = $doc->consultarPorCorreo($_POST["correo"]);

        echo json_encode([
            "error"  => false,
            "perfil" => $result
        ]);
        exit;
    }
    
if ($api == "verificarCorreo") {

    if (!isset($_POST["correo"])) {
        echo json_encode(["error" => true, "msg" => "Falta el correo"]);
        exit;
    }

    $correo = $_POST["correo"];

    // 🔧 NUEVO: CONEXIÓN CORRECTA
    $pdo = Conexion::conectar();

    $sql = $pdo->prepare("SELECT id_docente FROM docente WHERE correo = ?");
    $sql->execute([$correo]);

    echo json_encode([
        "error" => false,
        "existe" => $sql->rowCount() > 0
    ]);
    exit;
}


    // ==========================================================
    // 🟩 ACTUALIZAR GENERO Y GRADO
    // ==========================================================
    if ($api == "actualizar") {

        if (!isset($_POST["id_docente"], $_POST["genero"], $_POST["grado"])) {
            throw new Exception("Faltan parámetros");
        }

        $ok = $doc->actualizarGeneroGrado(
            $_POST["id_docente"], 
            $_POST["genero"], 
            $_POST["grado"]
        );

        echo json_encode([
            "error" => !$ok,
            "msg"   => $ok ? "Actualizado correctamente" : "No se pudo actualizar"
        ]);
        exit;
    }


    // ==========================================================
    // 🟨 CAMBIAR CONTRASEÑA
    // ==========================================================
    if ($api == "cambiarpass") {

        if (!isset($_POST["correo"], $_POST["nueva"])) {
            throw new Exception("Faltan parámetros");
        }

        $ok = $doc->cambiarPass($_POST["correo"], $_POST["nueva"]);

        echo json_encode([
            "error" => !$ok,
            "msg"   => $ok ? "Contraseña actualizada correctamente" : "No se pudo actualizar contraseña"
        ]);
        exit;
    }

    throw new Exception("API no válida");

} catch (Exception $e) {

    echo json_encode([
        "error" => true,
        "msg" => $e->getMessage()
    ]);
    exit;
}
?>
