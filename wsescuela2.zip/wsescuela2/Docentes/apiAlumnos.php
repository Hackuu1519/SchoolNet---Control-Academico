<?php
require_once "ADAlumno.php";
require_once "Conexion.php";

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

if (!isset($_GET["api"])) {
    echo json_encode(["error" => true, "msg" => "API no definida"]);
    exit;
}

$api = $_GET["api"];

try {

   // =================================================================
// 1️⃣ SOLICITUDES PENDIENTES (estado = )
// =================================================================
if ($api == "solicitudes") {

        if (!isset($_POST["id_grupo"])) {
            echo json_encode(["error" => true, "msg" => "Falta id_grupo"]);
            exit;
        }

        $solicitudes = ADAlumno::solicitudes($_POST["id_grupo"]);

        echo json_encode([
            "error" => false,
            "solicitudes" => $solicitudes
        ]);

        exit;
                        }

    // =================================================================
    // 2️⃣ ACEPTAR SOLICITUD (estado → 2)
    // =================================================================
    if ($api == "aceptar") {

        if (!isset($_POST["id_inscripcion"])) {
            echo json_encode(["error" => true, "msg" => "Falta id_inscripcion"]);
            exit;
        }

        ADAlumno::aceptar($_POST["id_inscripcion"]);

        echo json_encode([
            "error" => false,
            "msg" => "Alumno aceptado correctamente"
        ]);
        exit;
    }



    // =================================================================
    // 3️⃣ RECHAZAR SOLICITUD (eliminar inscripción)
    // =================================================================
    if ($api == "rechazar") {

        if (!isset($_POST["id_inscripcion"])) {
            echo json_encode(["error" => true, "msg" => "Falta id_inscripcion"]);
            exit;
        }

        ADAlumno::rechazar($_POST["id_inscripcion"]);

        echo json_encode([
            "error" => false,
            "msg" => "Solicitud rechazada correctamente"
        ]);
        exit;
    }



    // =================================================================
    // 4️⃣ LISTA DE ALUMNOS ACEPTADOS (estado = 2)
    // =================================================================
    if ($api == "lista") {

        if (!isset($_POST["id_grupo"])) {
            echo json_encode(["error" => true, "msg" => "Falta id_grupo"]);
            exit;
        }

        $lista = ADAlumno::lista($_POST["id_grupo"]);

        echo json_encode([
            "error" => false,
            "alumnos" => $lista
        ]);
        exit;
    }



    // =================================================================
    // 5️⃣ ELIMINAR ALUMNO DEL GRUPO
    // =================================================================
    if ($api == "eliminar") {

        if (!isset($_POST["id_inscripcion"])) {
            echo json_encode(["error" => true, "msg" => "Falta id_inscripcion"]);
            exit;
        }

        ADAlumno::eliminar($_POST["id_inscripcion"]);

        echo json_encode([
            "error" => false,
            "msg" => "Alumno eliminado del grupo"
        ]);
        exit;
    }



    // =================================================================
    // ❌ API NO VÁLIDA
    // =================================================================
    echo json_encode(["error" => true, "msg" => "API no válida"]);
    exit;



} catch (Exception $e) {

    echo json_encode([
        "error" => true,
        "msg" => "Error: " . $e->getMessage()
    ]);
    exit;
}
