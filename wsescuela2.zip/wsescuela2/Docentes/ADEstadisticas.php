<?php
require_once "Conexion.php";

class ADEstadisticas {

    public function estadisticasGrupo($idGrupo) {

    $pdo = Conexion::conectar();

    // TOTAL
    $sql = $pdo->prepare("
        SELECT COUNT(*) AS total
        FROM inscripcion
        WHERE id_grupo = ? AND estado = 2
    ");
    $sql->execute([$idGrupo]);
    $total = $sql->fetchColumn();

    // HOY
    $hoy = date("Y-m-d");

    $sql = $pdo->prepare("
        SELECT 
            SUM(valor = 1) AS asistencias,
            SUM(valor = 2) AS permisos,
            SUM(valor = 3) AS faltas,
            SUM(valor = 4) AS justificadas
        FROM pase

        WHERE id_grupo = ? AND fecha = ?
    ");
    $sql->execute([$idGrupo, $hoy]);
    $h = $sql->fetch(PDO::FETCH_ASSOC);

    // HISTORIAL ÚLTIMOS 7 DÍAS
    $sql = $pdo->prepare("
        SELECT fecha, SUM(estado=1) as asistencias
        FROM pase
        WHERE id_grupo = ?
        GROUP BY fecha
        ORDER BY fecha DESC
        LIMIT 7
    ");
    $sql->execute([$idGrupo]);
    $historial = $sql->fetchAll(PDO::FETCH_ASSOC);

    // ALUMNOS EN RIESGO (<80%)
    $sql = $pdo->prepare("
        SELECT 
            e.nombre,
            ROUND( (SUM(p.estado = 1) / COUNT(*)) * 100 , 2 ) AS porcentaje
        FROM pase p
        INNER JOIN estudiante e ON e.id_estudiante = p.id_estudiante
        WHERE p.id_grupo = ?
        GROUP BY p.id_estudiante
        HAVING porcentaje < 80
    ");
    $sql->execute([$idGrupo]);
    $riesgo = $sql->fetchAll(PDO::FETCH_ASSOC);

    return [
        "error" => false,
        "msg" => [
            "total_alumnos"     => $total,
            "asistencias_hoy"   => $h["asistencias"] ?? 0,
            "permisos_hoy"      => $h["permisos"] ?? 0,
            "faltas_hoy"        => $h["faltas"] ?? 0,
            "justificadas_hoy"  => $h["justificadas"] ?? 0,
            "historial"         => $historial,
            "alumnos_riesgo"    => $riesgo
        ]
    ];
}


    public function obtenerEstadisticas($idGrupo) {

        $pdo = Conexion::conectar();

        // 1️⃣ TOTAL DE ALUMNOS
        $sql = $pdo->prepare("SELECT COUNT(*) FROM inscripcion WHERE id_grupo = ?");
        $sql->execute([$idGrupo]);
        $total = $sql->fetchColumn();

        // 2️⃣ ASISTENCIAS DEL DÍA
        $hoy = date("Y-m-d");

        $sql = $pdo->prepare("
            SELECT 
                SUM(CASE WHEN pase = 1 THEN 1 ELSE 0 END) AS asistencias_hoy,
                SUM(CASE WHEN pase = 2 THEN 1 ELSE 0 END) AS permisos_hoy,
                SUM(CASE WHEN pase = 3 THEN 1 ELSE 0 END) AS faltas_hoy,
                SUM(CASE WHEN pase = 4 THEN 1 ELSE 0 END) AS justificadas_hoy
            FROM pase
            WHERE id_grupo = ? AND fecha = ?
        ");
        $sql->execute([$idGrupo, $hoy]);
        $hoyData = $sql->fetch(PDO::FETCH_ASSOC);

        // 3️⃣ HISTORIAL (últimos 7 días)
        $sql = $pdo->prepare("
            SELECT fecha,
                   SUM(CASE WHEN pase = 1 THEN 1 ELSE 0 END) AS asistencias
            FROM pase
            WHERE id_grupo = ?
            GROUP BY fecha
            ORDER BY fecha DESC
            LIMIT 7
        ");
        $sql->execute([$idGrupo]);
        $historial = $sql->fetchAll(PDO::FETCH_ASSOC);

        // 4️⃣ ALUMNOS EN RIESGO (<80%)
        $sql = $pdo->prepare("
            SELECT 
                CONCAT(e.app, ' ', e.apm, ' ', e.nombre) AS nombre,
                ROUND( (SUM(p.pase = 1) / COUNT(*)) * 100, 1 ) AS porcentaje
            FROM pase p
            INNER JOIN estudiante e ON e.id_estudiante = p.id_estudiante
            WHERE p.id_grupo = ?
            GROUP BY p.id_estudiante
            HAVING porcentaje < 80
            ORDER BY porcentaje ASC
        ");
        $sql->execute([$idGrupo]);
        $riesgo = $sql->fetchAll(PDO::FETCH_ASSOC);

        // 5️⃣ SALIDA FINAL
        return [
            "error" => false,
            "msg" => [
                "total_alumnos"    => intval($total),
                "asistencias_hoy"  => intval($hoyData["asistencias_hoy"]),
                "faltas_hoy"       => intval($hoyData["faltas_hoy"]),
                "permisos_hoy"     => intval($hoyData["permisos_hoy"]),
                "justificadas_hoy" => intval($hoyData["justificadas_hoy"]),
                "historial"        => $historial,
                "alumnos_riesgo"   => $riesgo
            ]
        ];
    }
}
