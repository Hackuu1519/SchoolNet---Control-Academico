<?php
require_once "Conexion.php";

class ADClase {

    // ---------------------------------------------
    // NORMALIZAR HORA (soporte +24h)
    // ---------------------------------------------
    private function formatoHora($h) {
        $h = intval($h);

        // Ej: 2500 → 1 día extra + 01:00
        $diasExtra = intdiv($h, 2400);
        $horaReal = $h % 2400;

        $horaReal = str_pad($horaReal, 4, "0", STR_PAD_LEFT);

        return [
            "hora" => substr($horaReal, 0, 2) . ":" . substr($horaReal, 2, 2),
            "dias_extra" => $diasExtra
        ];
    }

    // ---------------------------------------------
    // FORMATEAR FECHA REAL SEGÚN EL DÍA (1–6)
    // ---------------------------------------------
    private function formatearClase($row) {
        date_default_timezone_set("America/Mexico_City");

        $f = $this->formatoHora($row["inicio"]);

        // Crear fecha desde hoy
        $fecha = new DateTime("today");

        // Avanzar hasta coincidir con el día esperado
        while (intval($fecha->format("N")) !== intval($row["dia"])) {
            $fecha->modify("+1 day");
        }

        // Si la hora supera 24h, sumar días adicionales
        if ($f["dias_extra"] > 0) {
            $fecha->modify("+{$f['dias_extra']} day");
        }

        return [
            "grupo"           => $row["id_grupo"],
            "materia"         => $row["materia"],
            "clave"           => $row["grupo_clave"],
            "nombre_completo" => $row["materia"] . " — " . $row["grupo_clave"],
            "fecha"           => $fecha->format("Y-m-d"),
            "hora"            => $f["hora"],
            "aula"            => $row["aula"]
        ];
    }

    // ---------------------------------------------
    // LISTAR TODAS LAS SIGUIENTES CLASES ACTIVAS
    // ---------------------------------------------
    public function todasLasClases($idDocente) {
        $con = Conexion::conectar();
        date_default_timezone_set("America/Mexico_City");

        $sql = "
            SELECT 
                g.id_grupo,
                g.Asignatura AS materia,
                g.clave AS grupo_clave,
                h.dia,
                h.inicio,
                h.aula
            FROM horario h
            INNER JOIN grupo g ON g.id_grupo = h.id_grupo
            WHERE g.id_docente = :doc
              AND g.estado = 1               -- SOLO ACTIVAS
              AND h.dia BETWEEN 1 AND 6      -- Lunes–Sábado
            ORDER BY h.dia ASC, h.inicio ASC
        ";

        $stmt = $con->prepare($sql);
        $stmt->bindValue(":doc", $idDocente);
        $stmt->execute();

        $lista = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $lista[] = $this->formatearClase($row);
        }

        return count($lista) > 0 ? $lista : false;
    }
}
