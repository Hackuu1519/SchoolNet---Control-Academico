<?php
require_once "Conexion.php";
require_once "config.php";

class ADAsistencia {


    private $pdo;

    public function __construct() {
        $this->pdo = Conexion::conectar();
    }

    public function estadisticasGrupo($idGrupo) {
    date_default_timezone_set('America/Mexico_City'); // ← Faltaba
    $pdo = Conexion::conectar();

    // TOTAL ALUMNOS
    $sql = $pdo->prepare("
        SELECT COUNT(*) 
        FROM inscripcion
        WHERE id_grupo = ? AND estado = 2
    ");
    $sql->execute([$idGrupo]);
    $total = $sql->fetchColumn();

    // HOY
    $hoy = date("Y-m-d");

    $sql = $pdo->prepare("
        SELECT 
            SUM(valor = 1) AS asistencias,
            SUM(valor = 2) AS permisos,
            SUM(valor = 3) AS faltas,
            SUM(valor = 4) AS justificadas
        FROM pase
        WHERE id_inscripcion IN (
            SELECT id_inscripcion FROM inscripcion 
            WHERE id_grupo = ? AND estado = 2
        )
        AND fecha = ?
    ");
    $sql->execute([$idGrupo, $hoy]);
    $h = $sql->fetch(PDO::FETCH_ASSOC);

    // HISTORIAL
    $sql = $pdo->prepare("
        SELECT fecha, SUM(valor = 1) as asistencias
        FROM pase
        WHERE id_inscripcion IN (
            SELECT id_inscripcion FROM inscripcion 
            WHERE id_grupo = ? AND estado = 2
        )
        GROUP BY fecha
        ORDER BY fecha ASC
        LIMIT 7
    ");
    $sql->execute([$idGrupo]);
    $historial = $sql->fetchAll(PDO::FETCH_ASSOC);

    // RIESGO
    $sql = $pdo->prepare("
        SELECT 
            CONCAT(e.app, ' ', e.apm, ' ', e.nombre) AS nombre,
            ROUND((SUM(p.valor = 1) / COUNT(*)) * 100, 2) AS porcentaje
        FROM pase p
        INNER JOIN inscripcion i ON p.id_inscripcion = i.id_inscripcion
        INNER JOIN estudiante e ON e.id_estudiante = i.id_estudiante
        WHERE i.id_grupo = ?
        GROUP BY i.id_estudiante
        HAVING porcentaje < 80
    ");
    $sql->execute([$idGrupo]);
    $riesgo = $sql->fetchAll(PDO::FETCH_ASSOC);

    return [
        "error" => false,
        "msg" => [
            "total_alumnos"    => intval($total),
            "asistencias_hoy"  => intval($h["asistencias"] ?? 0),
            "permisos_hoy"     => intval($h["permisos"] ?? 0),
            "faltas_hoy"       => intval($h["faltas"] ?? 0),
            "justificadas_hoy" => intval($h["justificadas"] ?? 0),
            "historial"        => $historial,
            "alumnos_riesgo"   => $riesgo
        ]
    ];
}


    /* ============================================================
       1️⃣ REGISTRO MANUAL
    ============================================================ */
    public function registrarManual($idGrupo, $idAlumno, $estado) {

        date_default_timezone_set('America/Mexico_City');
        $fecha = date("Y-m-d");

        $sql = $this->pdo->prepare("
            SELECT id_inscripcion
            FROM inscripcion
            WHERE id_grupo = ? AND id_estudiante = ? AND estado = 2
            LIMIT 1
        ");
        $sql->execute([$idGrupo, $idAlumno]);
        $ins = $sql->fetch(PDO::FETCH_ASSOC);

        if (!$ins) {
            return ["error"=>true, "msg"=>"El alumno no está aceptado."];
        }

        $idIns = $ins["id_inscripcion"];

        $sql = $this->pdo->prepare("
            SELECT id_pase
            FROM pase
            WHERE id_inscripcion = ? AND fecha = ?
        ");
        $sql->execute([$idIns, $fecha]);

        if ($sql->rowCount() > 0) {
            $idPase = $sql->fetch(PDO::FETCH_ASSOC)["id_pase"];

            $upd = $this->pdo->prepare("UPDATE pase SET valor = ? WHERE id_pase = ?");
            $upd->execute([$estado, $idPase]);

            return ["error"=>false, "msg"=>"Asistencia actualizada"];
        }

        $ins = $this->pdo->prepare("
            INSERT INTO pase (id_inscripcion, fecha, valor)
            VALUES (?, ?, ?)
        ");
        $ins->execute([$idIns, $fecha, $estado]);

        return ["error"=>false, "msg"=>"Asistencia registrada"];
    }   

    public function editar($idInscripcion, $estado) {

    date_default_timezone_set('America/Mexico_City');
    $fecha = date("Y-m-d");

    // Verificar si hay pase existente
    $sql = $this->pdo->prepare("
        SELECT id_pase FROM pase
        WHERE id_inscripcion = ? AND fecha = ?
        LIMIT 1
    ");
    $sql->execute([$idInscripcion, $fecha]);
    $pase = $sql->fetch(PDO::FETCH_ASSOC);

    if ($pase) {
        // Actualizar
        $upd = $this->pdo->prepare("
            UPDATE pase SET valor = ?
            WHERE id_pase = ?
        ");
        $upd->execute([$estado, $pase["id_pase"]]);

        return ["error"=>false, "msg"=>"Asistencia actualizada"];
    }

    // Insertar (si no existía)
    $ins = $this->pdo->prepare("
        INSERT INTO pase(id_inscripcion, fecha, valor)
        VALUES (?, ?, ?)
    ");
    $ins->execute([$idInscripcion, $fecha, $estado]);

    return ["error"=>false, "msg"=>"Asistencia registrada"];
}


public function editarPase($idPase, $estado)
{
    $sql = $this->pdo->prepare("
        UPDATE pase 
        SET valor = ? 
        WHERE id_pase = ?
    ");
    
    $sql->execute([$estado, $idPase]);

    return [
        "error" => false,
        "msg" => "Asistencia actualizada correctamente"
    ];
}


    /* ============================================================
       2️⃣ REGISTRO QR
    ============================================================ */
    public function registrarQR($codigo, $idGrupo) {

        date_default_timezone_set('America/Mexico_City');
        $fecha = date("Y-m-d");

        $partes = explode("|", $codigo);

        $idG      = $partes[0] ?? null;
        $idAlumno = $partes[1] ?? null;
        $letra    = $partes[2] ?? "A";

        if ($idG != $idGrupo) {
            return ["error"=>true, "msg"=>"QR no pertenece al grupo"];
        }

        // A=1, P=2, F=3, J=4
        $map = ["A"=>1, "P"=>2, "F"=>3, "J"=>4];
        $valor = $map[$letra] ?? 1;

        // Validar inscripción
        $sql = $this->pdo->prepare("
            SELECT id_inscripcion
            FROM inscripcion
            WHERE id_grupo = ? AND id_estudiante = ? AND estado = 2
            LIMIT 1
        ");
        $sql->execute([$idGrupo, $idAlumno]);
        $row = $sql->fetch(PDO::FETCH_ASSOC);

        if (!$row) {
            return ["error"=>true, "msg"=>"Alumno no aceptado"];
        }

        $idIns = $row["id_inscripcion"];

        // Verificar pase del día
        $sql = $this->pdo->prepare("
            SELECT id_pase
            FROM pase
            WHERE id_inscripcion = ? AND fecha = ?
            LIMIT 1
        ");
        $sql->execute([$idIns, $fecha]);
        $pase = $sql->fetch(PDO::FETCH_ASSOC);

        if ($pase) {
            $upd = $this->pdo->prepare("
                UPDATE pase SET valor = ?
                WHERE id_pase = ?
            ");
            $upd->execute([$valor, $pase["id_pase"]]);

            return ["error"=>false, "msg"=>"Pase actualizado"];
        }

        // Insertar nuevo
        $ins = $this->pdo->prepare("
            INSERT INTO pase (id_inscripcion, fecha, valor)
            VALUES (?, ?, ?)
        ");
        $ins->execute([$idIns, $fecha, $valor]);

        return ["error"=>false, "msg"=>"Pase registrado"];
    }

    /* ============================================================
       ⭐ REGISTRO GPS MASIVO
    ============================================================ */
    public function registrarGPSMasivo($idGrupo, $presentes, $faltantes) {

        date_default_timezone_set('America/Mexico_City');
        $fecha = date("Y-m-d");

        $sql = $this->pdo->prepare("
            SELECT id_inscripcion, id_estudiante
            FROM inscripcion
            WHERE id_grupo = ? AND estado = 2
        ");
        $sql->execute([$idGrupo]);
        $all = $sql->fetchAll(PDO::FETCH_ASSOC);

        $contA = 0;
        $contF = 0;

        foreach ($all as $al) {

            $idIns = $al["id_inscripcion"];
            $idEst = $al["id_estudiante"];

            $sql = $this->pdo->prepare("
                SELECT id_pase
                FROM pase
                WHERE id_inscripcion = ? AND fecha = ?
            ");
            $sql->execute([$idIns, $fecha]);
            $pase = $sql->fetch(PDO::FETCH_ASSOC);

            // valor: 1 = presente, 3 = falta
            $valor = in_array($idEst, $presentes) ? 1 : 3;

            if ($pase) {
                $upd = $this->pdo->prepare("
                    UPDATE pase SET valor = ?
                    WHERE id_pase = ?
                ");
                $upd->execute([$valor, $pase["id_pase"]]);
            } else {
                $ins = $this->pdo->prepare("
                    INSERT INTO pase(id_inscripcion, fecha, valor)
                    VALUES (?, ?, ?)
                ");
                $ins->execute([$idIns, $fecha, $valor]);
            }

            if ($valor == 1) $contA++;
            else $contF++;
        }

        return [
            "error" => false,
            "msg" => "Registradas $contA asistencias y $contF faltas"
        ];
    }


   /* ============================================================
   📄 GENERAR PDF DEL GRUPO
============================================================ */
public function generarPDF($idGrupo, $inicio, $fin, $rutaPDF) {

    $pdo = Conexion::conectar();

    // Obtener datos
    $sql = $pdo->prepare("
        SELECT 
            e.matricula,
            CONCAT(e.app, ' ', e.apm, ' ', e.nombre) AS alumno,
            p.fecha,
            p.valor
        FROM pase p
        INNER JOIN inscripcion i ON i.id_inscripcion = p.id_inscripcion
        INNER JOIN estudiante e ON e.id_estudiante = i.id_estudiante
        WHERE i.id_grupo = ?
        AND p.fecha BETWEEN ? AND ?
        ORDER BY e.app, e.apm, e.nombre, p.fecha
    ");
    $sql->execute([$idGrupo, $inicio, $fin]);
    $rows = $sql->fetchAll(PDO::FETCH_ASSOC);

    // Sin datos
    if (!$rows || count($rows) == 0) {
        return ["error"=>true, "msg"=>"No hay asistencias registradas en ese período"];
    }

    // PDF
    require_once "fpdf/fpdf.php";

    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont("Arial","B",16);
    $pdf->Cell(0,10,"Reporte de Asistencias",0,1,"C");

    $pdf->SetFont("Arial","",12);
    $pdf->Cell(0,8,"Grupo: $idGrupo",0,1);
    $pdf->Cell(0,8,"Del: $inicio al $fin",0,1);
    $pdf->Ln(5);

    $pdf->SetFont("Arial","B",10);
    $pdf->Cell(30,8,"Matricula",1);
    $pdf->Cell(70,8,"Alumno",1);
    $pdf->Cell(30,8,"Fecha",1);
    $pdf->Cell(30,8,"Estado",1);
    $pdf->Ln();

    $mapEstado = [1=>"A", 2=>"P", 3=>"F", 4=>"J"];

    $pdf->SetFont("Arial","",10);

    foreach ($rows as $r) {
        $pdf->Cell(30,8,utf8_decode($r["matricula"]),1);
        $pdf->Cell(70,8,utf8_decode($r["alumno"]),1);
        $pdf->Cell(30,8,$r["fecha"],1);
        $pdf->Cell(30,8,$mapEstado[$r["valor"]] ?? "-",1);
        $pdf->Ln();
    }

    // Guardar PDF
    $pdf->Output("F", $rutaPDF);

    return ["error"=>false, "msg"=>"PDF generado"];
}



    /* ============================================================
       ✔ 3️⃣ INFO DEL ALUMNO (encabezado)
    ============================================================ */
    public function infoAlumno($idEstudiante, $idGrupo) {

        $sql = $this->pdo->prepare("
            SELECT 
                e.id_estudiante,
                e.nombre,
                e.app,
                e.apm,
                e.matricula,
                e.genero,
                e.carrera,
                CONCAT('" . URL_BASE_ALUMNOS . "', e.id_estudiante, '.jpg') AS foto
            FROM estudiante e
            INNER JOIN inscripcion i ON i.id_estudiante = e.id_estudiante
            WHERE i.id_estudiante = ? AND i.id_grupo = ? AND i.estado = 2
            LIMIT 1
        ");
        $sql->execute([$idEstudiante, $idGrupo]);
        $row = $sql->fetch(PDO::FETCH_ASSOC);

        if (!$row) {
            return ["error"=>true, "msg"=>"Alumno no encontrado"];
        }

        return ["error"=>false, "msg"=>$row];
    }


    /* ============================================================
       ✔ 4️⃣ RESUMEN DEL ALUMNO
    ============================================================ */
    public function resumen($idEstudiante, $idGrupo) {

        $sql = $this->pdo->prepare("
            SELECT id_inscripcion
            FROM inscripcion
            WHERE id_estudiante = ? AND id_grupo = ? AND estado = 2
            LIMIT 1
        ");
        $sql->execute([$idEstudiante, $idGrupo]);
        $ins = $sql->fetch(PDO::FETCH_ASSOC);

        if (!$ins) {
            return ["error"=>true, "msg"=>"Alumno no inscrito"];
        }

        $idIns = $ins["id_inscripcion"];

        $sql = $this->pdo->prepare("
            SELECT
                SUM(valor = 1) AS asistencias,
                SUM(valor = 2) AS permisos,
                SUM(valor = 3) AS faltas,
                SUM(valor = 4) AS justificantes

            FROM pase
            WHERE id_inscripcion = ?
        ");
        $sql->execute([$idIns]);
        $data = $sql->fetch(PDO::FETCH_ASSOC);

        return ["error"=>false, "msg"=>$data];
    }


    /* ============================================================
       ✔ 5️⃣ HISTORIAL DEL ALUMNO
    ============================================================ */
    public function historial($idEstudiante, $idGrupo) {

       $sql = $this->pdo->prepare("
    SELECT id_pase, fecha, valor AS estado
    FROM pase
    WHERE id_inscripcion = ?
    ORDER BY fecha DESC, id_pase DESC
    LIMIT 20
");

        $sql->execute([$idEstudiante, $idGrupo]);
        $ins = $sql->fetch(PDO::FETCH_ASSOC);

        if (!$ins) {
            return ["error"=>true, "msg"=>"Alumno no encontrado"];
        }

        $sql = $this->pdo->prepare("
           SELECT fecha, valor AS estado
            FROM pase
            WHERE id_inscripcion = ?
            ORDER BY fecha DESC, id_pase DESC
            LIMIT 20
        ");
        $sql->execute([$ins["id_inscripcion"]]);
        $rows = $sql->fetchAll(PDO::FETCH_ASSOC);

        return ["error"=>false, "msg"=>$rows];
    }

    /* ============================================================
   LISTA PARA REGISTRO MANUAL
   Devuelve:
   estado = 0 sin marcar
   estado = 1 asistencia
   estado = 2 permiso
   estado = 3 falta
   estado = 4 justificado
============================================================ */
public function listaManual($idGrupo) {

    date_default_timezone_set('America/Mexico_City');
    $fecha = date("Y-m-d");

    $sql = $this->pdo->prepare("
        SELECT 
            e.id_estudiante AS id_alumno,
            e.nombre,
            e.app,
            e.apm,
            e.matricula,
            e.genero,
            CONCAT('" . URL_BASE_ALUMNOS  . "', e.id_estudiante, '.jpg') AS foto,
            i.id_inscripcion,
            
            (
                SELECT valor 
                FROM pase 
                WHERE pase.id_inscripcion = i.id_inscripcion 
                AND pase.fecha = ?
                LIMIT 1
            ) AS estado

        FROM inscripcion i
        INNER JOIN estudiante e ON e.id_estudiante = i.id_estudiante
        WHERE i.id_grupo = ? AND i.estado = 2
        ORDER BY e.app, e.apm, e.nombre
    ");

    $sql->execute([$fecha, $idGrupo]);
    $rows = $sql->fetchAll(PDO::FETCH_ASSOC);

    return ["error"=>false, "msg"=>$rows];
}


    /* ============================================================
       ✔ 6️⃣ HORARIO DEL GRUPO
    ============================================================ */
    public function horario($idGrupo) {

        $sql = $this->pdo->prepare("
            SELECT dia, inicio, fin, aula
            FROM horario
            WHERE id_grupo = ?
            ORDER BY dia ASC, inicio ASC
        ");
        $sql->execute([$idGrupo]);
        $rows = $sql->fetchAll(PDO::FETCH_ASSOC);

        return ["error"=>false, "msg"=>$rows];
    }
}
