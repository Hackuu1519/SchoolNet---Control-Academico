<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET");
header("Access-Control-Allow-Headers: Content-Type");

require_once "ADClase.php";

$response = [];

if (!isset($_GET["api"])) {
    echo json_encode(["error" => true, "msg" => "No API"]);
    exit;
}

switch ($_GET["api"]) {

    case "proxima_clase":

        $idDoc = $_POST['id_docente'] ?? null;

        if (!$idDoc) {
            $response["error"] = true;
            $response["msg"] = "Falta id_docente";
            break;
        }

        $db = new ADClase();
        $res = $db->todasLasClases($idDoc); // ← lista completa con fechas reales

        if ($res) {
            $response["error"] = false;
            $response["clases"] = $res;
        } else {
            $response["error"] = true;
            $response["msg"] = "Sin clases registradas";
        }
    break;

    case "debug_hora":
    date_default_timezone_set("America/Mexico_City");
    echo json_encode([
        "hora_mexico" => date("Y-m-d H:i:s"),
        "timezone"    => date_default_timezone_get()
    ]);
    exit;


    default:
        $response["error"] = true;
        $response["msg"] = "API no válida";
}

echo json_encode($response);
