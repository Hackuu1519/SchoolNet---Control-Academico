<?php
require_once "Conexion.php";
require_once "fpdf/fpdf.php";

class ReportePDF extends FPDF {

    // Encabezado profesional
    function Header() {

        // Logo
        if (file_exists("logo.png")) {
            $this->Image("logo.png", 10, 8, 20);
        }

        // Título general
        $this->SetFont("Arial", "B", 16);
        $this->Cell(0, 10, utf8_decode("Reporte de Asistencias"), 0, 1, "C");

        // Línea
        $this->Ln(5);
        $this->SetDrawColor(31, 66, 90);
        $this->Line(10, 28, 200, 28);

        $this->Ln(10);
    }

    // Pie de página
    function Footer() {
        $this->SetY(-15);
        $this->SetFont("Arial", "I", 8);
        $this->SetTextColor(150, 150, 150);
        $this->Cell(0, 10, utf8_decode("Generado automáticamente por SchoolNet | Página " . $this->PageNo()), 0, 0, "C");
    }



    // Función principal
    public function generar($idGrupo, $inicio, $fin) {

        $pdo = Conexion::conectar();

        // ================================
        //  OBTENER INFORMACIÓN DEL GRUPO
        // ================================
        $sqlGrupo = $pdo->prepare("
            SELECT 
                g.clave,
                g.carrera,
                g.periodo,
                g.Asignatura,
                CONCAT(d.nombre,' ',d.app,' ',d.apm) AS docente
            FROM grupo g
            INNER JOIN docente d ON d.id_docente = g.id_docente
            WHERE g.id_grupo = ?
        ");
        $sqlGrupo->execute([$idGrupo]);
        $grupo = $sqlGrupo->fetch(PDO::FETCH_ASSOC);


        // ================================
        //  OBTENER ASISTENCIAS DEL PERIODO
        // ================================
        $sql = $pdo->prepare("
            SELECT 
                e.matricula,
                CONCAT(e.app,' ',e.apm,' ',e.nombre) AS nombre,
                p.fecha,
                p.valor
            FROM pase p
            INNER JOIN inscripcion i ON i.id_inscripcion = p.id_inscripcion
            INNER JOIN estudiante e ON e.id_estudiante = i.id_estudiante
            WHERE i.id_grupo = ?
            AND p.fecha BETWEEN ? AND ?
            ORDER BY p.fecha ASC, nombre ASC
        ");
        $sql->execute([$idGrupo, $inicio, $fin]);
        $registros = $sql->fetchAll(PDO::FETCH_ASSOC);


        // ================================
        //  CREAR PDF
        // ================================
        $this->AddPage();
        $this->SetFont("Arial", "", 12);

        // Título
        $this->SetTextColor(31, 66, 90);
        $this->SetFont("Arial", "B", 12);
        $this->Cell(0, 8, utf8_decode("Información del grupo"), 0, 1);

        // Datos del grupo
        $this->SetFont("Arial", "", 11);
        $this->SetTextColor(0);

        $this->Cell(100, 6, utf8_decode("Clave: " . ($grupo["clave"] ?? "N/A")), 0, 0);
        $this->Cell(0, 6, utf8_decode("Asignatura: " . ($grupo["Asignatura"] ?? "N/A")), 0, 1);

        $this->Cell(100, 6, utf8_decode("Carrera: " . ($grupo["carrera"] ?? "N/A")), 0, 0);
        $this->Cell(0, 6, utf8_decode("Docente: " . ($grupo["docente"] ?? "N/A")), 0, 1);

        $this->Cell(0, 6, utf8_decode("Periodo: " . ($grupo["periodo"] ?? "N/A")), 0, 1);

        $this->Ln(5);
        $this->SetFont("Arial", "I", 11);
        $this->SetTextColor(80, 80, 80);
        $this->Cell(0, 6, utf8_decode("Rango de fechas: $inicio  al  $fin"), 0, 1);

        $this->Ln(8);



        // ================================
        // TABLA DE ASISTENCIAS
        // ================================
        $this->SetFont("Arial", "B", 11);
        $this->SetFillColor(31, 66, 90);
        $this->SetTextColor(255, 255, 255);

        $this->Cell(30, 8, "Fecha", 1, 0, "C", true);
        $this->Cell(35, 8, "Matricula", 1, 0, "C", true);
        $this->Cell(85, 8, utf8_decode("Nombre"), 1, 0, "C", true);
        $this->Cell(30, 8, "Estado", 1, 1, "C", true);

        $this->SetFont("Arial", "", 10);
        $this->SetTextColor(0);

        $fill = false;

        foreach ($registros as $r) {

            $estado = [
                1 => "Asistencia",
                2 => "Permiso",
                3 => "Falta",
                4 => "Justificada",
            ][$r["valor"]] ?? "N/A";

            $this->SetFillColor(240, 240, 240);

            $this->Cell(30, 7, $r["fecha"], 1, 0, "C", $fill);
            $this->Cell(35, 7, $r["matricula"], 1, 0, "C", $fill);
            $this->Cell(85, 7, utf8_decode($r["nombre"]), 1, 0, "L", $fill);
            $this->Cell(30, 7, utf8_decode($estado), 1, 1, "C", $fill);

            $fill = !$fill;
        }


        // ================================
        // GUARDAR PDF
        // ================================
        $nombrePDF = "reportes/reporte_" . time() . ".pdf";

        if (!file_exists("reportes")) {
            mkdir("reportes", 0777, true);
        }

        $this->Output("F", $nombrePDF);

        return "http://192.168.1.236/wsescuela2/Docentes/" . $nombrePDF;
    }
}
