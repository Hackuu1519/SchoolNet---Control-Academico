<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");

require_once "Conexion.php";

if (!isset($_GET["id_grupo"])) {
    echo json_encode(["error" => true, "msg" => "Falta id_grupo"]);
    exit;
}

$idGrupo = $_GET["id_grupo"];
$cn = Conexion::conectar();

/* ---------------------------------------------------------
   1. ALUMNOS ACEPTADOS DEL GRUPO
--------------------------------------------------------- */
$sql = $cn->prepare("
    SELECT e.id_estudiante,
           CONCAT_WS(' ', e.nombre, e.app, e.apm) AS nombre
    FROM inscripcion i
    INNER JOIN estudiante e ON e.id_estudiante = i.id_estudiante
    WHERE i.id_grupo = :grupo AND i.estado = 2
");

$sql->bindParam(":grupo", $idGrupo);
$sql->execute();
$alumnos = $sql->fetchAll(PDO::FETCH_ASSOC);

if (!$alumnos) {
    echo json_encode(["error" => true, "msg" => "No hay alumnos aceptados"]);
    exit;
}

/* ---------------------------------------------------------
   2. LEER ARCHIVOS JSON DEL ALUMNO
--------------------------------------------------------- */
$carpeta = "../Alumnos/ubicacion_estudiante/";
$resultado = [];

foreach ($alumnos as $al) {
    $id = $al["id_estudiante"];
    $archivo = $carpeta . $id . ".json";

    if (file_exists($archivo)) {

        $contenido = file_get_contents($archivo);
        $json = json_decode($contenido, true);

        if ($json && isset($json["latitud"]) && isset($json["longitud"])) {
            $resultado[] = [
                "id_estudiante" => $id,
                "nombre" => $al["nombre"],
                "latitud" => (float)$json["latitud"],
                "longitud" => (float)$json["longitud"],
                "fecha" => $json["fecha"]
            ];
        }
    }
}

/* ---------------------------------------------------------
   3. RESPUESTA
--------------------------------------------------------- */
if (empty($resultado)) {
    echo json_encode([
        "error" => true,
        "msg" => "Ningún alumno ha enviado ubicación"
    ]);
    exit;
}

echo json_encode([
    "error" => false,
    "alumnos" => $resultado
]);
