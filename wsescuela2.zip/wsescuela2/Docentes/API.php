<?php
// ============================================
//  API para subir y descargar imágenes de DOCENTES
// ============================================

// Encabezados para permitir solicitudes desde Android
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

$response = array();

// Verifica si existe apicall
if (!isset($_GET['apicall'])) {
    echo json_encode([
        "error" => true,
        "message" => "No se recibió ninguna llamada a la API."
    ]);
    exit;
}

$api = $_GET['apicall'];

// =============================================
// 📤 SUBIR FOTO
// =============================================
if ($api === "foto") {

    if (!isset($_POST['archivo'])) {
        echo json_encode(["error" => true, "message" => "No se recibió ninguna imagen Base64."]);
        exit;
    }

    if (!isset($_POST['id_docente'])) {
        echo json_encode(["error" => true, "message" => "No se recibió id_docente."]);
        exit;
    }

    $id = $_POST['id_docente'];
    $imagenBase64 = $_POST['archivo'];

    // Decodificar imagen
    $imagenDecodificada = base64_decode($imagenBase64);

    // Carpeta
    $carpetaDestino = 'archivos/';
    if (!file_exists($carpetaDestino)) {
        mkdir($carpetaDestino, 0777, true);
    }

    // Nombre correcto del archivo
    $nombreArchivo = "docente_" . $id . ".jpg";

    // Guardar archivo
    if (file_put_contents($carpetaDestino . $nombreArchivo, $imagenDecodificada)) {
        echo json_encode([
            "error" => false,
            "message" => "Archivo cargado con éxito",
            "archivo" => $nombreArchivo
        ]);
    } else {
        echo json_encode([
            "error" => true,
            "message" => "Error al guardar el archivo."
        ]);
    }
    exit;
}



// =============================================
// 📥 DESCARGAR FOTO
// =============================================
if ($api === "bajarfoto") {

    if (!isset($_POST['id_docente'])) {
        echo json_encode([
            "error" => true,
            "message" => "No se recibió id_docente."
        ]);
        exit;
    }

    $id = $_POST['id_docente'];
    $rutaArchivo = 'archivos/docente_' . $id . '.jpg';

    if (file_exists($rutaArchivo)) {

        $imagenBase64 = base64_encode(file_get_contents($rutaArchivo));

        echo json_encode([
            "error" => false,
            "contenido" => $imagenBase64
        ]);
    } else {

        echo json_encode([
            "error" => true,
            "message" => "No se encontró imagen docente_" . $id . ".jpg"
        ]);
    }
    exit;
}

if (isset($_GET['apicall'])) {

    switch ($_GET['apicall']) {

        case 'eliminarfoto':

            if (!isset($_POST['id_docente'])) {
                echo json_encode([
                    "error" => true,
                    "msg" => "Falta id_docente"
                ]);
                exit;
            }

            $id = $_POST['id_docente'];
            $ruta = "archivos/" . $id . ".jpg";

            if (file_exists($ruta)) {
                unlink($ruta);
                echo json_encode([
                    "error" => false,
                    "msg" => "Foto eliminada"
                ]);
            } else {
                echo json_encode([
                    "error" => false,
                    "msg" => "No existía foto"
                ]);
            }
            break;
    }
}



// =============================================
// 🛑 API NO VÁLIDA
// =============================================
echo json_encode([
    "error" => true,
    "message" => "Petición no válida"
]);
exit;

?>
