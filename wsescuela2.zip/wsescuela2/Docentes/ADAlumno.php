<?php
require_once "Conexion.php";
require_once "config.php";

class ADAlumno {

    // ============================================================
    // 1️⃣ Solicitudes pendientes (estado = 1)
    // ============================================================
    public static function solicitudes($idGrupo) {
        $con = Conexion::conectar();

        $sql = "
            SELECT 
                i.id_inscripcion,
                i.modalidad,
                e.id_estudiante,
                e.nombre,
                e.app,
                e.apm,
                e.matricula,
                CONCAT(e.app, ' ', e.apm, ' ', e.nombre) AS nombre_completo,
                CONCAT('" . URL_BASE_ALUMNOS . "', e.id_estudiante, '.jpg') AS foto
            FROM inscripcion i
            INNER JOIN estudiante e ON e.id_estudiante = i.id_estudiante
            WHERE i.id_grupo = :g AND i.estado = 1
            ORDER BY e.app, e.apm, e.nombre ASC
        ";

        $stmt = $con->prepare($sql);
        $stmt->bindParam(":g", $idGrupo);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }


    // ============================================================
    // 2️⃣ Aceptar solicitud (estado = 2)
    // ============================================================
    public static function aceptar($idInscripcion) {
        $con = Conexion::conectar();

        $stmt = $con->prepare("
            UPDATE inscripcion
            SET estado = 2
            WHERE id_inscripcion = :id
        ");

        $stmt->bindParam(":id", $idInscripcion);
        return $stmt->execute();
    }


    // ============================================================
    // 3️⃣ Rechazar solicitud
    // ============================================================
    public static function rechazar($idInscripcion) {
        $con = Conexion::conectar();

        $stmt = $con->prepare("
            DELETE FROM inscripcion
            WHERE id_inscripcion = :id
        ");

        $stmt->bindParam(":id", $idInscripcion);
        return $stmt->execute();
    }


    // ============================================================
    // 4️⃣ Lista de alumnos aceptados (estado = 2)
    // ============================================================
    public static function lista($idGrupo) {
        $con = Conexion::conectar();

        $sql = "
            SELECT 
                i.id_inscripcion,
                i.modalidad,
                e.id_estudiante AS id_alumno,
                e.nombre,
                e.app,
                e.apm,
                e.matricula,
                e.genero,
                CONCAT('" . URL_BASE_ALUMNOS . "', e.id_estudiante, '.jpg') AS foto
            FROM inscripcion i
            INNER JOIN estudiante e ON e.id_estudiante = i.id_estudiante
            WHERE i.id_grupo = :g AND i.estado = 2
            ORDER BY e.app ASC, e.apm ASC, e.nombre ASC
        ";

        $stmt = $con->prepare($sql);
        $stmt->bindParam(":g", $idGrupo);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }


    // ============================================================
    // 5️⃣ Eliminar alumno del grupo
    // ============================================================
    public static function eliminar($idInscripcion) {
        $con = Conexion::conectar();

        $stmt = $con->prepare("
            DELETE FROM inscripcion
            WHERE id_inscripcion = :id
        ");

        $stmt->bindParam(":id", $idInscripcion);
        return $stmt->execute();
    }
}
